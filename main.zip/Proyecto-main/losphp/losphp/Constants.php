<?php
    define("DB_HOST", "192.168.1.142");
    define("DB_USER", "mnko");
    define("DB_PASSWORD", "12341234");
    define("DB_DATABASE", "login");
?>
